from fastapi import HTTPException
from ..config import GEMINI_API_KEY, GEMINI_MODEL

def ask_gemini(prompt):
    if not GEMINI_API_KEY: raise HTTPException(503,"Chưa cấu hình GEMINI_API_KEY trong backend/.env.")
    try:
        from google import genai
        client=genai.Client(api_key=GEMINI_API_KEY)
        response=client.models.generate_content(model=GEMINI_MODEL,contents=prompt)
        return response.text or "AI chưa tạo được câu trả lời."
    except Exception as error:
        raise HTTPException(502, f"Dịch vụ AI đang gặp lỗi: {str(error)[:200]}")
